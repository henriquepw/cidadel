vim.pack.add({
  {
		src = "https://github.com/nvim-treesitter/nvim-treesitter",
		branch = "main",
		build = ":TSUpdate",
	},
	"https://www.github.com/neovim/nvim-lspconfig",
	"https://github.com/mason-org/mason.nvim",
	{
		src = "https://github.com/saghen/blink.cmp",
		version = vim.version.range("1.*"),
	},
})

local map = vim.keymap.set

local setup_treesitter = function()
	local treesitter = require("nvim-treesitter")
	treesitter.setup({})
	local ensure_installed = {
		"vim",
		"vimdoc",
		"rust",
		"c",
		"cpp",
		"go",
		"html",
		"css",
		"javascript",
		"json",
		"lua",
		"markdown",
		"typescript",
		"bash",
		"zig",
	}

	local config = require("nvim-treesitter.config")

	local already_installed = config.get_installed()
	local parsers_to_install = {}

	for _, parser in ipairs(ensure_installed) do
		if not vim.tbl_contains(already_installed, parser) then
			table.insert(parsers_to_install, parser)
		end
	end

	if #parsers_to_install > 0 then
		treesitter.install(parsers_to_install)
	end

	local group = vim.api.nvim_create_augroup("TreeSitterConfig", { clear = true })
	vim.api.nvim_create_autocmd("FileType", {
		group = group,
		callback = function(args)
			if vim.list_contains(treesitter.get_installed(), vim.treesitter.language.get_lang(args.match)) then
				vim.treesitter.start(args.buf)
			end
		end,
	})
end

local setup_mason = function()
	require("mason").setup({})
	local ensure_installed = {
    "lua-language-server",
    "rust-analyzer",
    -- Golang
    "gopls",
    "goimports-reviser",
    -- TS
    "biome",
    "vtsls",
	}

	local registry = require("mason-registry")

  for _, pkg in ipairs(ensure_installed) do
    if not registry.is_installed(pkg) then
      registry.get_package(pkg):install()
    end
	end

  registry.update()
end

setup_mason()
setup_treesitter()

map("n", "<leader>cm", "<cmd>Mason<cr>", { desc = "Mason" })
