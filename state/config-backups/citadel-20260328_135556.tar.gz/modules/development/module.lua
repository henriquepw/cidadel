local packages = {
	"android-studio",
	"clang",
	"cmake",
	"curl",
	"git",
	"github-cli",
	"unzip",
	"yazi",
	"opencode-bin",
	"tmux",
	"nvm",
	"bun",
	"go",
	"rust",
	"zig",
	"lazygit",
	"lazydocker",
	"ghostty",
	"alacritty",
	"zsh",
	"neovim-git",
  "gc",
  "tree-sitter-cli"
}

return {
	description = "Development tools",
	post_install_hook = "scripts/setup.sh",
	hook_behavior = "once",
	packages = packages,
	conflicts = {},
}
