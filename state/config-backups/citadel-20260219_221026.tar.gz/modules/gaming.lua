local packages = {
	"steam",
	"heroic-games-launcher-bin",
	"gamescope",
	"mangohud",
	"protonplus",
	"sunshine",
	"discord",
	"flatpak:im.riot.Riot",
	"flatpak:im.fluffychat.Fluffychat",
}

return {
	description = "Gaming packages and tools for Linux gaming",
	packages = packages,
}
