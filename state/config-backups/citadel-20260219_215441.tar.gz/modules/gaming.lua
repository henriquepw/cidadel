local packages = {
	"steam",
	"heroic-games-launcher-bin",
	"gamescope",
	"mangohud",
	"protonplus",
	"sunshine",
	"discord",
	"flatpak:in.cinny.Cinny",
}

return {
	description = "Gaming packages and tools for Linux gaming",
	packages = packages,
}
