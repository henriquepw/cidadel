local packages = {
	"stow",
}

return {
	description = "Dotfiles",
	dotfiles_sync = true,
	dotfiles = {
		{
			source = "home/*",
			target = "~/*",
		},
	},
	packages = packages,
}
